🇰🇭 CamCurrency Demo Kit

HOW TO USE ON ANY COMPUTER:

1. Install Docker Desktop (Required):
   Download here: https://www.docker.com/products/docker-desktop/

2. Run the App:
   Double-click "Start_App.bat"

3. Stop the App:
   Double-click "Stop_App.bat"

---
Notes:
- The first run will take a few minutes to download the app (approx 4GB).
- Requires Internet connection for the first run.
